/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kopp.exercicio1;

import java.text.DecimalFormat;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Henrique Cerentini
 */
public class ListProcessing {

    private ArrayList<Double> listaEntrada;
    private double somaTotal;
    
    public void addValorLista(double valor){
        listaEntrada.add(valor);
    }
    
    public void removeValorLista(double valor){
        listaEntrada.remove(valor);
    }
   
    public void setListaEntrada(ArrayList<Double> listaEntrada) {
        this.listaEntrada = listaEntrada;
    }

    public ArrayList<Double> getListaEntrada() {
        return listaEntrada;
    }
    
    public double getSomaTotal() {
        return somaTotal;
    }

    public void setSomaTotal(double somaTotal) {
        this.somaTotal = somaTotal;
    }
    
    public ListProcessing(ArrayList<Double> lista) {
        listaEntrada = lista;
    }
    
    public ListProcessing() {
        listaEntrada = new ArrayList<Double>();
    }
    
    //Processa a lista de números, retornando os valores de maneira indexada, além de fornecer o valor somatório no final;
    public double proccessList() {
        double total = 0;
        int index = 1;
        System.out.println("-- Valores Detalhados -- ");
        System.out.println("Remessa Gerada:");
        for (double var : listaEntrada) {
            total += var;
            System.out.println("[" + index + "] Cujo valor é R$" + String.format("%.2f", var));
            index++;
        }
        System.out.println("Total = " + String.format("%.2f", total));
        setSomaTotal(total);
        return total;
    }
  
}
