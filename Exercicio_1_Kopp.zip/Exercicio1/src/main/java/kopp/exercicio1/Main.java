/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kopp.exercicio1;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author Henrique Cerentini
 */
public class Main {

    public static void main(String[] args) {
        ArrayList<Double> listaEntrada = new ArrayList<>(Arrays.asList(88.00,130.00,54.90,293.30,44.80));
        ListProcessing lista = new ListProcessing(listaEntrada);
        lista.proccessList();
    }
}
